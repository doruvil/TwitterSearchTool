function getTweetText() {
    return document.getElementById('views').getElementsByClassName('dir-ltr').item(0).textContent;
}

function countWords(s) {
    s = s.replace(/(^\s*)|(\s*$)/gi,"");
    s = s.replace(/[ ]{2,}/gi," ");
    s = s.replace(/\n /,"\n");
    return s.split(' ').length;
}

function insertAfterTweet(text) {
    var divCounter = document.createElement('div');
    var afterDiv = document.getElementById('views').getElementsByClassName('tweet-text').item(0);

    divCounter.innerHTML = text;
    afterDiv.parentNode.insertBefore(divCounter, afterDiv.nextSibling);
}

